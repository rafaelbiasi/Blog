package br.com.rafaelbiasi.blog.mapper;

import br.com.rafaelbiasi.blog.data.CommentData;
import br.com.rafaelbiasi.blog.model.Comment;
import org.mapstruct.InjectionStrategy;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingConstants;

@Mapper(
        componentModel = MappingConstants.ComponentModel.SPRING,
        injectionStrategy = InjectionStrategy.SETTER,
        uses = {
                SqidsConverterMapper.class,
                PostMapper.class,
                AccountMapper.class
        }
)
public interface CommentMapper {

    @Mapping(source = "id", target = "code", qualifiedByName = "IdToCodeSqids")
    CommentData commentToCommentData(Comment comment);

    @Mapping(target = "creation", ignore = true)
    @Mapping(target = "modified", ignore = true)
    @Mapping(source = "code", target = "id", qualifiedByName = "CodeSqidsToId")
    Comment commentDataToComment(CommentData commentData);
}