package br.com.rafaelbiasi.blog.service;

import br.com.rafaelbiasi.blog.model.Comment;

import java.util.Optional;

public interface CommentService extends EntityService<Comment> {

    Optional<Comment> findByCode(final String code);

    Comment save(final Comment comment);
}
