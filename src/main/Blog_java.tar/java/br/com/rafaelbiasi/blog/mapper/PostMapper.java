package br.com.rafaelbiasi.blog.mapper;

import br.com.rafaelbiasi.blog.data.PostData;
import br.com.rafaelbiasi.blog.model.Post;
import org.mapstruct.*;

@Mapper(
        componentModel = MappingConstants.ComponentModel.SPRING,
        injectionStrategy = InjectionStrategy.SETTER,
        uses = {
                SqidsConverterMapper.class,
                CommentMapper.class,
                AccountMapper.class
        }
)
public interface PostMapper {

    @Mapping(source = "id", target = "code", qualifiedByName = "IdToCodeSqids")
    PostData postToPostData(Post post);

    @Named("withoutComments")
    @Mapping(target = "comments", ignore = true)
    @Mapping(source = "id", target = "code", qualifiedByName = "IdToCodeSqids")
    PostData postToPostDataWithoutComments(Post post);

    @Mapping(target = "creation", ignore = true)
    @Mapping(target = "modified", ignore = true)
    @Mapping(source = "code", target = "id", qualifiedByName = "CodeSqidsToId")
    Post postDataToPost(PostData postData);

    @Mapping(target = "creation", ignore = true)
    @Mapping(target = "modified", ignore = true)
    @Mapping(source = "code", target = "id", qualifiedByName = "CodeSqidsToId")
    void updatePostFromData(PostData postData, @MappingTarget Post post);
}