package br.com.rafaelbiasi.blog.repository;

import br.com.rafaelbiasi.blog.model.Comment;
import org.springframework.stereotype.Repository;

@Repository
public interface CommentRepository extends BlogRepository<Comment> {

}
