package br.com.rafaelbiasi.blog.service;

import br.com.rafaelbiasi.blog.model.Account;
import br.com.rafaelbiasi.blog.microtype.RegistrationResponse;

import java.util.Optional;

public interface AccountService extends EntityService<Account> {

    Optional<Account> findOneByEmail(final String email);

    Optional<Account> findOneByUsername(final String username);

    void registerUser(final Account account);

    RegistrationResponse checkEmailAndUsernameExists(final Account account);
}
