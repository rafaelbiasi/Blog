package br.com.rafaelbiasi.blog.controller;

import br.com.rafaelbiasi.blog.data.CommentData;
import br.com.rafaelbiasi.blog.data.PostData;
import br.com.rafaelbiasi.blog.facade.PostFacade;
import jakarta.servlet.http.HttpServletRequest;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.support.RequestContextUtils;

import static br.com.rafaelbiasi.blog.exception.ResourceNotFoundExceptionFactory.throwPostNotFound;
import static java.util.Optional.ofNullable;

@Slf4j
@Controller
@RequiredArgsConstructor
@RequestMapping("/post/")
public class PostController {

    public static final String REDIRECT_POST = "redirect:/post/{code}/{slugifiedTitle}/";

    private static final String POST_VIEW = "post/post";

    private final PostFacade postFacade;

    @GetMapping("/{code}/{slugifiedTitle}/")
    public String post(
            final @PathVariable String code,
            final @PathVariable String slugifiedTitle,
            final Model model,
            final HttpServletRequest request
    ) {
        log.info(
                "Entering the post page. Parameters [{}={}]",
                "Code", code
        );
        postFacade.findByCode(code).ifPresentOrElse(
                post -> addToModelAttribute(model, request, post),
                () -> throwPostNotFound(code)
        );
        return POST_VIEW;
    }

    private void addToModelAttribute(
            final Model model,
            final HttpServletRequest request,
            final PostData post
    ) {
        model.addAttribute("post", post);
        addFlashAttributeWhenError(model, request);
        addCommentAttribute(model);
    }

    private void addFlashAttributeWhenError(
            final Model model,
            final HttpServletRequest request
    ) {
        ofNullable(RequestContextUtils.getInputFlashMap(request)).ifPresent(model::addAllAttributes);
    }

    private void addCommentAttribute(final Model model) {
        if (!model.containsAttribute("comment")) {
            model.addAttribute("comment", new CommentData());
        }
    }
}
