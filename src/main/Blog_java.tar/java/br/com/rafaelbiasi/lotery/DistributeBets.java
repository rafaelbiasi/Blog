package br.com.rafaelbiasi.lotery;

import lombok.Getter;
import lombok.val;

import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.*;
import java.util.function.Function;

import static java.util.Comparator.comparing;

public class DistributeBets {

    private static final double BUDGET = 30d;
    private static final Locale LOCALE_BR = Locale.of("pt", "BR");

    public static void main(final String[] args) {
        System.out.println("\nDistribuindo apostas para prêmios custo beneficio mais facil:");
        distributeBets(BUDGET, Lottery::calculateCostBenefitOnlyEasiest);

        System.out.println("\nDistribuindo apostas para prêmios custo beneficio mais dificil:");
        distributeBets(BUDGET, Lottery::calculateCostBenefitOnlyMostDifficult);

        System.out.println("\nDistribuindo apostas para prêmios custo beneficio média (com e sem acumulado):");
        distributeBets(BUDGET, Lottery::calculateCostBenefitAverage);

        System.out.println("\nDistribuindo apostas para prêmios custo beneficio sem acumulado:");
        distributeBets(BUDGET, Lottery::calculateCostBenefitWithoutJackpot);

        System.out.println("\nDistribuindo apostas para prêmios custo beneficio com acumulado:");
        distributeBets(BUDGET, Lottery::calculateCostBenefit);

        System.out.println("\nDistribuindo apostas para prêmios altos:");
        distributeBets(BUDGET, lottery -> lottery.calculateCostBenefitLargerPrizes(10_000_000, 5));

        System.out.println("\nDistribuindo apostas para prêmios menores:");
        distributeBets(BUDGET, lottery -> lottery.calculateCostBenefitSmallerPrizes(10_000_000, 5));

        System.out.println("\nDistribuindo apostas para somente o prêmio menor:");
        distributeBets(BUDGET, Lottery::calculateCostBenefitOnlySmallest);

        System.out.println("\nDistribuindo apostas para somente o prêmio alto:");
        distributeBets(BUDGET, Lottery::calculateCostBenefitOnlyLargest);
    }

    public static void distributeBets(
            final double budget,
            final Function<Lottery, Double> calculateCostBenefit
    ) {
        checkMinimumBudget().filter(lottery -> budget >= lottery.getPrice())
                .ifPresentOrElse(lottery -> {
                    val costBenefitMap = computeCostBenefit(calculateCostBenefit);
                    val betsPerGame = betsByCostBenefit(budget, costBenefitMap);
                    addExtraBets(betsPerGame, budget, costBenefitMap);
                    displayResult(betsPerGame, budget, calculateCostBenefit);
                }, () -> System.out.println("Orçamento insuficiente para realizar qualquer aposta."));
    }

    private static Optional<Lottery> checkMinimumBudget() {
        return Arrays.stream(Lottery.values()).min(Comparator.comparingDouble(Lottery::getPrice));
    }

    private static Map<Lottery, Double> computeCostBenefit(final Function<Lottery, Double> costBenefitCalculation) {
        val costBenefitMap = new HashMap<Lottery, Double>();
        val values = Arrays.stream(Lottery.values())
                .sorted(comparing(costBenefitCalculation).reversed())
                .toList();
        values.forEach(lottery -> {
            final double costBenefit = costBenefitCalculation.apply(lottery);
            costBenefitMap.put(lottery, costBenefit);
        });
        return costBenefitMap;
    }

    private static Map<Lottery, Integer> betsByCostBenefit(
            final double budget,
            final Map<Lottery, Double> costBenefitMap
    ) {
        val betsPerGame = new HashMap<Lottery, Integer>();
        val sumCostBenefit = costBenefitMap.values().stream().mapToDouble(Double::doubleValue).sum();
        val sortedLotteries = new ArrayList<>(costBenefitMap.keySet());
        sortedLotteries.sort((l1, l2) -> costBenefitMap.get(l2).compareTo(costBenefitMap.get(l1)));
        sortedLotteries.forEach(lottery -> {
            val proportion = costBenefitMap.get(lottery) / sumCostBenefit;
            val numberOfBets = (int) Math.floor(budget * proportion / lottery.getPrice());
            betsPerGame.put(lottery, numberOfBets);
        });
        return betsPerGame;
    }

    private static void addExtraBets(
            final Map<Lottery, Integer> betsPerGame,
            final double budget,
            final Map<Lottery, Double> costBenefitMap
    ) {
        val totalBetsValue = betsPerGame.entrySet().stream()
                .mapToDouble(e -> e.getKey().getPrice() * e.getValue())
                .sum();
        var remaining = budget - totalBetsValue;
        val sortedLotteries = new ArrayList<>(costBenefitMap.keySet());
        sortedLotteries.sort((l1, l2) -> costBenefitMap.get(l2).compareTo(costBenefitMap.get(l1)));
        for (var lottery : sortedLotteries) {
            while (remaining >= lottery.getPrice()) {
                betsPerGame.put(lottery, betsPerGame.get(lottery) + 1);
                remaining -= lottery.getPrice();
            }
        }
    }

    private static void displayResult(
            final Map<Lottery, Integer> betsPerGame,
            final double budget,
            final Function<Lottery, Double> calculateCostBenefit
    ) {
        val sortedList = betsPerGame.entrySet()
                .stream()
                .sorted((entry1, entry2) -> entry2.getValue().compareTo(entry1.getValue()))
                .toList();
        var totalBetsValue = 0d;
        var totalProbabilityNotWinning = 1.0;
        val symbols = getDecimalFormatSymbols();
        val decimalFormat = new DecimalFormat("#,###", symbols);
        val currencyFormat = new DecimalFormat("#,##0.00", symbols);
        val jackpots = new HashMap<Lottery, Integer>();
        for (var entry : sortedList) {
            val lottery = entry.getKey();
            val numberOfBets = entry.getValue();
            if (numberOfBets > 0) {
                var totalBetValueForGame = numberOfBets * lottery.getPrice();
                totalBetsValue += totalBetValueForGame;
                val effectiveDifficulty = (double) lottery.getDifficulty() / numberOfBets;
                val individualProbability = (double) numberOfBets / lottery.getDifficulty();
                totalProbabilityNotWinning *= (1 - individualProbability);
                jackpots.put(lottery, lottery.getJackpot());
                displayBet(
                        calculateCostBenefit,
                        numberOfBets,
                        lottery,
                        totalBetValueForGame,
                        decimalFormat,
                        effectiveDifficulty
                );
            }
        }
        displayTotals(
                budget,
                jackpots,
                currencyFormat,
                decimalFormat,
                totalBetsValue,
                totalProbabilityNotWinning
        );
    }

    private static DecimalFormatSymbols getDecimalFormatSymbols() {
        val symbols = new DecimalFormatSymbols(LOCALE_BR);
        symbols.setGroupingSeparator('.');
        symbols.setDecimalSeparator(',');
        return symbols;
    }

    private static void displayBet(
            final Function<Lottery, Double> calculateCostBenefit,
            final int numberOfBets,
            final Lottery lottery,
            final double totalBetValueForGame,
            final DecimalFormat decimalFormat,
            final double effectiveDifficulty
    ) {
        System.out.println("Apostar "
                + numberOfBets
                + " vezes no jogo "
                + lottery.name()
                + " com valor total de R$ "
                + String.format(LOCALE_BR, "%.2f", totalBetValueForGame)
                + ", custo benefício: " + calculateCostBenefit.apply(lottery).intValue()
                + ", dificuldade efetiva: " + decimalFormat.format(effectiveDifficulty)
        );
    }

    private static void displayTotals(
            final double budget,
            final Map<Lottery, Integer> jackpots,
            final DecimalFormat currencyFormat,
            final DecimalFormat decimalFormat,
            final double totalBetsValue,
            final double totalProbabilityNotWinning
    ) {
        val smallestPossiblePrize = jackpots.entrySet()
                .stream()
                .min(Map.Entry.comparingByValue())
                .orElseThrow();
        System.out.println(
                "Valor total de todas as apostas: R$ "
                        + currencyFormat.format(totalBetsValue
                ));
        System.out.println(
                "Orçamento restante: R$ "
                        + currencyFormat.format(budget - totalBetsValue)
        );
        double probabilityOfWinning = 1 - totalProbabilityNotWinning;
        if (probabilityOfWinning == 0) {
            System.out.println("Probabilidade total de ganhar pelo menos um jogo: 0");
        } else {
            System.out.println(
                    "Probabilidade total de ganhar pelo menos um jogo: "
                            + " (1 em "
                            + decimalFormat.format(1 / probabilityOfWinning)
                            + "), "
                            + "menor prêmio possível: R$ "
                            + currencyFormat.format(smallestPossiblePrize.getValue())
                            + " do jogo: " + smallestPossiblePrize.getKey()
            );
        }
    }

    @Getter
    public enum Lottery {

        MAIS_MILIONARIA(6.00, 13_000_000, 238_360_500),
        MEGA_SENA(5.00, 40_000_000, 50_063_860),
        //        MEGA_DA_VIRADA(5.00, 600_000_000, 50_063_860),
        TIMEMANIA(3.50, 3_800_000, 26_472_637),
        QUINA(2.50, 13_000_000, 24_040_016),
        DUPLA_SENA(2.50, 3_600_000, 15_890_700),
        LOTOMANIA(3.00, 2_400_000, 11_372_635),
        SUPER_SETE(2.50, 1_700_000, 10_000_000),
        LOTOFACIL(3.00, 4_000_000, 3_268_760),
        DIA_DE_SORTE(2.50, 350_000, 262_957),
        ;

        private static final long FIX = 1_000L;

        private final double price;
        private final int difficulty;
        private final int jackpot;

        Lottery(final double price, final int jackpot, final int difficulty) {
            this.price = price;
            this.difficulty = difficulty;
            this.jackpot = jackpot;
        }

        public double calculateCostBenefitOnlyEasiest() {
            val easiest = Arrays.stream(values())
                    .map(Lottery::getDifficulty)
                    .min(Integer::compareTo)
                    .orElseThrow();
            return difficulty == easiest ? easiest : 0;
        }

        public double calculateCostBenefitOnlyMostDifficult() {
            val mostDifficult = Arrays.stream(values())
                    .map(Lottery::getDifficulty)
                    .max(Integer::compareTo)
                    .orElseThrow();
            return difficulty == mostDifficult ? mostDifficult : 0;
        }

        public double calculateCostBenefitAverage() {
            return (calculateCostBenefitWithoutJackpot() + calculateCostBenefit()) / 2;
        }

        public double calculateCostBenefit() {
            return jackpot / (difficulty * price) * FIX;
        }

        public double calculateCostBenefitWithoutJackpot() {
            val highest = Arrays.stream(values())
                    .map(Lottery::getJackpot)
                    .max(Integer::compareTo)
                    .orElseThrow();
            return highest / (difficulty * price) * FIX;
        }

        public double calculateCostBenefitSmallerPrizes(int smallerPrize, int factor) {
            return (jackpot < smallerPrize ? factor : 1) * jackpot / (difficulty * price) * FIX;
        }

        public double calculateCostBenefitLargerPrizes(final int largerPrize, final int factor) {
            return (jackpot > largerPrize ? factor : 1) * jackpot / (difficulty * price) * FIX;
        }

        public double calculateCostBenefitOnlyLargest() {
            val largestPrize = Arrays.stream(values())
                    .map(Lottery::getJackpot)
                    .max(Integer::compareTo)
                    .orElseThrow();
            return jackpot == largestPrize ? largestPrize : 0;
        }

        public double calculateCostBenefitOnlySmallest() {
            val smallestPrize = Arrays.stream(values())
                    .map(Lottery::getJackpot)
                    .min(Integer::compareTo)
                    .orElseThrow();
            return jackpot == smallestPrize ? smallestPrize : 0;
        }
    }
}
